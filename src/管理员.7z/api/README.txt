本文件夹下包含了管理员前端各个接口
1. acl是权限管理接口文件主要包含：
        role.js角色权限，
        user.js用户管理，
        menu.js菜单管理
2. edu是课程管理及讲师管理接口文件，包括
        teacher.js讲师管理，
        subject.js课程的分类
        course.js 课程管理
        chapter.js章节管理
        video.js  小节管理
3. Banner.js是轮播图接口文件
4. login.js是登录接口文件
5. order.js是订单管理接口文件
6. sta.js是数据统计接口文件
7. table.js项目框架自带