本文件夹下包含了管理员前端各个组件
1. Tinymce 富文本编辑器
2. ImageCropper 图片剪裁
3. PanThumb 缩略图
4. SvgIcon 图标组件
5. Hamburger 画布侧边栏组件
6. Breadcrumb 面包屑组件